import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { EmptyState, ErrorState, LoadingState } from "@/components/States";
import {
  createHealthCheck,
  deleteHealthCheck,
  listHealthChecks,
  updateHealthCheck,
} from "@/lib/dns-api";
import { HTTP_CODES, type HealthCheck, type HealthCheckType } from "@/lib/dns-types";

export const Route = createFileRoute("/health-checks")({
  head: () => ({
    meta: [
      { title: "Health Checks — Nimbus DNS Console" },
      {
        name: "description",
        content:
          "Configuraciones reutilizables de health check TCP y HTTP: timeout, reintentos, intervalo y basic auth.",
      },
      { property: "og:title", content: "Health Checks — Nimbus DNS Console" },
      {
        property: "og:description",
        content: "Cree y edite pruebas de salud TCP y HTTP para sus servicios.",
      },
    ],
  }),
  component: HealthChecksPage,
});

type Draft = Omit<HealthCheck, "id">;

const EMPTY: Draft = {
  name: "",
  type: "TCP",
  timeout: 5,
  retries: 3,
  interval: 30,
  path: "/health",
  expectedCodes: [200],
  basicAuthEnabled: false,
  username: "",
  password: "",
};

function HealthChecksPage() {
  const qc = useQueryClient();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["health-checks"],
    queryFn: listHealthChecks,
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["health-checks"] });
  const create = useMutation({ mutationFn: createHealthCheck, onSuccess: () => { invalidate(); close(); } });
  const update = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Draft }) => updateHealthCheck(id, data),
    onSuccess: () => { invalidate(); close(); },
  });
  const remove = useMutation({ mutationFn: deleteHealthCheck, onSuccess: invalidate });

  function close() {
    setDraft(null);
    setEditingId(null);
  }

  const saving = create.isPending || update.isPending;
  const nameInvalid = draft !== null && !draft.name.trim();

  return (
    <AppShell
      title="Health Checks"
      badge={data ? `${data.length} configurados` : undefined}
      actions={
        <button
          className="btn-primary"
          onClick={() => {
            setEditingId(null);
            setDraft({ ...EMPTY });
          }}
        >
          <span className="text-lg leading-none">+</span>Nueva configuración
        </button>
      }
    >
      {isLoading ? <LoadingState label="Cargando health checks…" /> : null}
      {isError ? <ErrorState error={error} onRetry={() => refetch()} /> : null}

      {draft ? (
        <form
          className="panel space-y-4 p-5"
          onSubmit={(e) => {
            e.preventDefault();
            if (!draft.name.trim()) return;
            if (editingId) update.mutate({ id: editingId, data: draft });
            else create.mutate(draft);
          }}
        >
          <p className="text-sm font-medium">
            {editingId ? "Editar health check" : "Nuevo health check"}
          </p>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <label className="lg:col-span-2">
              <span className="mb-1.5 block text-[11px] text-muted">Nombre identificador</span>
              <input
                value={draft.name}
                onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                placeholder="api-tcp-443"
                className="field font-mono"
              />
              {nameInvalid ? (
                <span className="mt-1 block text-[11px] text-red">El nombre es obligatorio</span>
              ) : null}
            </label>
            <label>
              <span className="mb-1.5 block text-[11px] text-muted">Tipo</span>
              <select
                value={draft.type}
                onChange={(e) => setDraft({ ...draft, type: e.target.value as HealthCheckType })}
                className="field"
              >
                <option value="TCP" className="bg-surface">TCP</option>
                <option value="HTTP" className="bg-surface">HTTP</option>
              </select>
            </label>
            <label>
              <span className="mb-1.5 block text-[11px] text-muted">Timeout (s)</span>
              <input
                type="number"
                min={1}
                value={draft.timeout}
                onChange={(e) => setDraft({ ...draft, timeout: Number(e.target.value) })}
                className="field font-mono"
              />
            </label>
            <label>
              <span className="mb-1.5 block text-[11px] text-muted">Reintentos</span>
              <input
                type="number"
                min={0}
                value={draft.retries}
                onChange={(e) => setDraft({ ...draft, retries: Number(e.target.value) })}
                className="field font-mono"
              />
            </label>
            <label>
              <span className="mb-1.5 block text-[11px] text-muted">Intervalo (s)</span>
              <input
                type="number"
                min={1}
                value={draft.interval}
                onChange={(e) => setDraft({ ...draft, interval: Number(e.target.value) })}
                className="field font-mono"
              />
            </label>

            {draft.type === "HTTP" ? (
              <>
                <label className="lg:col-span-2">
                  <span className="mb-1.5 block text-[11px] text-muted">Path</span>
                  <input
                    value={draft.path ?? ""}
                    onChange={(e) => setDraft({ ...draft, path: e.target.value })}
                    placeholder="/health"
                    className="field font-mono"
                  />
                </label>
                <div className="sm:col-span-2 lg:col-span-3">
                  <span className="mb-1.5 block text-[11px] text-muted">
                    Códigos HTTP esperados
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {HTTP_CODES.map((code) => {
                      const active = draft.expectedCodes?.includes(code) ?? false;
                      return (
                        <button
                          key={code}
                          type="button"
                          onClick={() =>
                            setDraft({
                              ...draft,
                              expectedCodes: active
                                ? (draft.expectedCodes ?? []).filter((c) => c !== code)
                                : [...(draft.expectedCodes ?? []), code],
                            })
                          }
                          className={`rounded-md px-2.5 py-1 font-mono text-xs ring-1 transition-colors ${
                            active
                              ? "bg-cyan/15 text-cyan ring-cyan/30"
                              : "text-muted ring-edge hover:text-ink"
                          }`}
                        >
                          {code}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </>
            ) : null}
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={draft.basicAuthEnabled}
              onChange={(e) => setDraft({ ...draft, basicAuthEnabled: e.target.checked })}
              className="size-4 accent-cyan"
            />
            El servicio requiere basic auth
          </label>

          {draft.basicAuthEnabled ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <label>
                <span className="mb-1.5 block text-[11px] text-muted">Usuario</span>
                <input
                  value={draft.username ?? ""}
                  onChange={(e) => setDraft({ ...draft, username: e.target.value })}
                  className="field"
                />
              </label>
              <label>
                <span className="mb-1.5 block text-[11px] text-muted">Contraseña</span>
                <input
                  type="password"
                  value={draft.password ?? ""}
                  onChange={(e) => setDraft({ ...draft, password: e.target.value })}
                  className="field"
                />
              </label>
            </div>
          ) : null}

          {create.isError || update.isError ? (
            <p className="text-sm text-red">No se pudo guardar la configuración.</p>
          ) : null}

          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="btn-primary disabled:opacity-60">
              {saving ? "Guardando…" : "Guardar"}
            </button>
            <button type="button" onClick={close} className="btn-ghost">
              Cancelar
            </button>
          </div>
        </form>
      ) : null}

      {data ? (
        <div className="panel overflow-hidden">
          <div className="flex h-12 items-center border-b border-edge/60 px-5">
            <p className="text-sm font-medium">Configuraciones reutilizables</p>
          </div>
          {data.length === 0 ? (
            <EmptyState label="Todavía no hay health checks configurados." />
          ) : (
            <div className="grid gap-px bg-edge/40 md:grid-cols-2 xl:grid-cols-3">
              {data.map((hc) => (
                <div key={hc.id} className="bg-surface/40 p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-sm">{hc.name}</span>
                    <span
                      className={`rounded-md px-2 py-0.5 font-mono text-[10px] ring-1 ${
                        hc.type === "TCP"
                          ? "bg-cyan/15 text-cyan ring-cyan/25"
                          : "bg-green/15 text-green ring-green/25"
                      }`}
                    >
                      {hc.type}
                    </span>
                  </div>
                  <div className="mt-2.5 grid grid-cols-3 gap-2 font-mono text-[11px] text-muted">
                    <div>
                      timeout<span className="mt-0.5 block text-sm text-ink">{hc.timeout}s</span>
                    </div>
                    <div>
                      retries<span className="mt-0.5 block text-sm text-ink">{hc.retries}</span>
                    </div>
                    <div>
                      intervalo<span className="mt-0.5 block text-sm text-ink">{hc.interval}s</span>
                    </div>
                  </div>
                  {hc.type === "HTTP" ? (
                    <div className="mt-2.5 grid grid-cols-2 gap-2 font-mono text-[11px] text-muted">
                      <div>
                        path<span className="mt-0.5 block text-sm text-ink">{hc.path}</span>
                      </div>
                      <div>
                        códigos
                        <span className="mt-0.5 block text-sm text-ink">
                          {(hc.expectedCodes ?? []).join(", ") || "—"}
                        </span>
                      </div>
                    </div>
                  ) : null}
                  <p className="mt-2.5 text-[11px] text-muted">
                    Basic auth: {hc.basicAuthEnabled ? `sí (${hc.username})` : "no"}
                  </p>
                  <div className="mt-3 flex items-center gap-2">
                    <button
                      onClick={() => {
                        const { id, ...rest } = hc;
                        setEditingId(id);
                        setDraft({ ...rest });
                      }}
                      className="text-xs font-medium text-muted hover:text-ink"
                    >
                      Editar
                    </button>
                    <span className="text-edge">/</span>
                    <button
                      onClick={() => {
                        if (confirm(`¿Eliminar ${hc.name}?`)) remove.mutate(hc.id);
                      }}
                      className="text-xs font-medium text-red/80 hover:text-red"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : null}
    </AppShell>
  );
}
