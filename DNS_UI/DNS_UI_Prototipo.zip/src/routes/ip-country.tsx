import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { EmptyState, ErrorState, LoadingState } from "@/components/States";
import {
  createIpCountry,
  deleteIpCountry,
  listIpCountries,
  updateIpCountry,
} from "@/lib/dns-api";
import { COUNTRIES, isValidIpv4, type IpCountryEntry } from "@/lib/dns-types";

export const Route = createFileRoute("/ip-country")({
  head: () => ({
    meta: [
      { title: "IP a País — Nimbus DNS Console" },
      {
        name: "description",
        content:
          "Base de datos de rangos de IP asociados a país y ciudad, usada por los registros DNS de tipo geo.",
      },
      { property: "og:title", content: "IP a País — Nimbus DNS Console" },
      {
        property: "og:description",
        content: "Administre los rangos de IP por país y ciudad.",
      },
    ],
  }),
  component: IpCountryPage,
});

type Draft = Omit<IpCountryEntry, "id">;
const EMPTY: Draft = { startIp: "", endIp: "", country: COUNTRIES[0]!, city: "" };
const PAGE_SIZE = 10;

function IpCountryPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [touched, setTouched] = useState(false);

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["ip-countries"],
    queryFn: listIpCountries,
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["ip-countries"] });
  const create = useMutation({ mutationFn: createIpCountry, onSuccess: () => { invalidate(); close(); } });
  const update = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Draft }) => updateIpCountry(id, data),
    onSuccess: () => { invalidate(); close(); },
  });
  const remove = useMutation({ mutationFn: deleteIpCountry, onSuccess: invalidate });

  function close() {
    setDraft(null);
    setEditingId(null);
    setTouched(false);
  }

  const filtered = (data ?? []).filter((e) =>
    e.country.toLowerCase().includes(search.trim().toLowerCase()),
  );
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const current = Math.min(page, pages);
  const rows = filtered.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);

  const ipsInvalid =
    draft !== null && (!isValidIpv4(draft.startIp) || !isValidIpv4(draft.endIp));

  return (
    <AppShell
      title="IP a País"
      badge={data ? `${data.length} rangos` : undefined}
      actions={
        <div className="flex items-center gap-2">
          <div className="relative">
            <span className="absolute top-1/2 left-3 -translate-y-1/2 text-sm text-muted">⌕</span>
            <input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Buscar por país…"
              aria-label="Buscar por país"
              className="field w-[200px] pl-9"
            />
          </div>
          <button
            className="btn-primary"
            onClick={() => {
              setEditingId(null);
              setDraft({ ...EMPTY });
            }}
          >
            <span className="text-lg leading-none">+</span>Nuevo rango
          </button>
        </div>
      }
    >
      {isLoading ? <LoadingState label="Cargando rangos de IP…" /> : null}
      {isError ? <ErrorState error={error} onRetry={() => refetch()} /> : null}

      {draft ? (
        <form
          className="panel space-y-4 p-5"
          onSubmit={(e) => {
            e.preventDefault();
            setTouched(true);
            if (ipsInvalid) return;
            if (editingId) update.mutate({ id: editingId, data: draft });
            else create.mutate(draft);
          }}
        >
          <p className="text-sm font-medium">{editingId ? "Editar rango" : "Nuevo rango"}</p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <label>
              <span className="mb-1.5 block text-[11px] text-muted">IP de inicio</span>
              <input
                value={draft.startIp}
                onChange={(e) => setDraft({ ...draft, startIp: e.target.value })}
                placeholder="10.0.0.0"
                className="field font-mono"
              />
              {touched && !isValidIpv4(draft.startIp) ? (
                <span className="mt-1 block text-[11px] text-red">Formato IPv4 inválido</span>
              ) : null}
            </label>
            <label>
              <span className="mb-1.5 block text-[11px] text-muted">IP de fin</span>
              <input
                value={draft.endIp}
                onChange={(e) => setDraft({ ...draft, endIp: e.target.value })}
                placeholder="10.0.255.255"
                className="field font-mono"
              />
              {touched && !isValidIpv4(draft.endIp) ? (
                <span className="mt-1 block text-[11px] text-red">Formato IPv4 inválido</span>
              ) : null}
            </label>
            <label>
              <span className="mb-1.5 block text-[11px] text-muted">País</span>
              <select
                value={draft.country}
                onChange={(e) => setDraft({ ...draft, country: e.target.value })}
                className="field"
              >
                {COUNTRIES.map((c) => (
                  <option key={c} value={c} className="bg-surface">
                    {c}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span className="mb-1.5 block text-[11px] text-muted">Ciudad (opcional)</span>
              <input
                value={draft.city ?? ""}
                onChange={(e) => setDraft({ ...draft, city: e.target.value })}
                className="field"
              />
            </label>
          </div>
          {create.isError || update.isError ? (
            <p className="text-sm text-red">No se pudo guardar el rango.</p>
          ) : null}
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={create.isPending || update.isPending}
              className="btn-primary disabled:opacity-60"
            >
              {create.isPending || update.isPending ? "Guardando…" : "Guardar"}
            </button>
            <button type="button" onClick={close} className="btn-ghost">
              Cancelar
            </button>
          </div>
        </form>
      ) : null}

      {data ? (
        <div className="panel overflow-hidden">
          <div className="flex h-12 items-center border-b border-edge/60 px-5">
            <p className="text-sm font-medium">{filtered.length} rangos</p>
          </div>
          {rows.length === 0 ? (
            <EmptyState label="No hay rangos que coincidan con la búsqueda." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-edge/60 text-left text-[11px] tracking-[0.12em] text-muted uppercase">
                    <th className="px-5 py-3 font-medium">IP inicio</th>
                    <th className="px-5 py-3 font-medium">IP fin</th>
                    <th className="px-5 py-3 font-medium">País</th>
                    <th className="px-5 py-3 font-medium">Ciudad</th>
                    <th className="px-5 py-3 text-right font-medium">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-edge/50">
                  {rows.map((entry) => (
                    <tr key={entry.id} className="transition-colors hover:bg-surface/60">
                      <td className="px-5 py-3.5 font-mono">{entry.startIp}</td>
                      <td className="px-5 py-3.5 font-mono text-muted">{entry.endIp}</td>
                      <td className="px-5 py-3.5">{entry.country}</td>
                      <td className="px-5 py-3.5 text-muted">{entry.city || "—"}</td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => {
                              const { id, ...rest } = entry;
                              setEditingId(id);
                              setDraft({ ...rest });
                            }}
                            className="text-xs font-medium text-muted hover:text-ink"
                          >
                            Editar
                          </button>
                          <span className="text-edge">/</span>
                          <button
                            onClick={() => {
                              if (confirm("¿Eliminar este rango?")) remove.mutate(entry.id);
                            }}
                            className="text-xs font-medium text-red/80 hover:text-red"
                          >
                            Eliminar
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="flex h-11 items-center justify-between border-t border-edge/60 px-5 font-mono text-[11px] text-muted">
            <span>
              Página {current} de {pages}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="grid size-7 place-items-center rounded-md text-muted ring-1 ring-edge"
              >
                ‹
              </button>
              {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className={`grid size-7 place-items-center rounded-md ${
                    p === current ? "bg-cyan font-medium text-base" : "text-muted ring-1 ring-edge"
                  }`}
                >
                  {p}
                </button>
              ))}
              <button
                onClick={() => setPage((p) => Math.min(pages, p + 1))}
                className="grid size-7 place-items-center rounded-md text-muted ring-1 ring-edge"
              >
                ›
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </AppShell>
  );
}
