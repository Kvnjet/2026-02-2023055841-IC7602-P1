import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { RecordForm } from "@/components/RecordForm";
import { createRecord } from "@/lib/dns-api";

export const Route = createFileRoute("/registros/nuevo")({
  head: () => ({
    meta: [
      { title: "Nuevo registro DNS — Nimbus DNS Console" },
      {
        name: "description",
        content: "Cree un registro DNS single, multi, round-trip, weight o geo con health checks.",
      },
      { property: "og:title", content: "Nuevo registro DNS — Nimbus DNS Console" },
      {
        property: "og:description",
        content: "Formulario de creación de registros DNS con validación de IPv4.",
      },
    ],
  }),
  component: NewRecord,
});

function NewRecord() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const create = useMutation({
    mutationFn: createRecord,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["records"] });
      navigate({ to: "/registros" });
    },
  });

  return (
    <AppShell title="Crear registro DNS">
      <RecordForm
        submitting={create.isPending}
        submitError={create.error}
        onSubmit={(data) => create.mutate(data)}
        onCancel={() => navigate({ to: "/registros" })}
      />
    </AppShell>
  );
}
