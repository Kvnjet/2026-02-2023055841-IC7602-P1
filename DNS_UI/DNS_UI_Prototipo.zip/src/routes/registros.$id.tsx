import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { RecordForm } from "@/components/RecordForm";
import { ErrorState, LoadingState } from "@/components/States";
import { getRecord, updateRecord } from "@/lib/dns-api";

export const Route = createFileRoute("/registros/$id")({
  head: () => ({
    meta: [
      { title: "Editar registro DNS — Nimbus DNS Console" },
      {
        name: "description",
        content: "Modifique las IPs, pesos, países y health checks de un registro DNS existente.",
      },
      { property: "og:title", content: "Editar registro DNS — Nimbus DNS Console" },
      {
        property: "og:description",
        content: "Edición de registros DNS con validación de direcciones IPv4.",
      },
    ],
  }),
  component: EditRecord,
});

function EditRecord() {
  const { id } = useParams({ from: "/registros/$id" });
  const navigate = useNavigate();
  const qc = useQueryClient();

  const record = useQuery({ queryKey: ["records", id], queryFn: () => getRecord(id) });
  const save = useMutation({
    mutationFn: (data: Parameters<typeof updateRecord>[1]) => updateRecord(id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["records"] });
      navigate({ to: "/registros" });
    },
  });

  return (
    <AppShell title="Editar registro DNS" badge={record.data?.hostname}>
      {record.isLoading ? <LoadingState /> : null}
      {record.isError ? (
        <ErrorState error={record.error} onRetry={() => record.refetch()} />
      ) : null}
      {record.data ? (
        <RecordForm
          initial={record.data}
          submitting={save.isPending}
          submitError={save.error}
          onSubmit={(data) => save.mutate(data)}
          onCancel={() => navigate({ to: "/registros" })}
        />
      ) : null}
    </AppShell>
  );
}
