import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { EmptyState, ErrorState, LoadingState } from "@/components/States";
import { deleteRecord, listRecords } from "@/lib/dns-api";
import type { RecordType } from "@/lib/dns-types";

export const Route = createFileRoute("/registros/")({
  head: () => ({
    meta: [
      { title: "Registros DNS — Nimbus DNS Console" },
      {
        name: "description",
        content:
          "Lista de registros DNS single, multi, round-trip, weight y geo con el estado de cada IP.",
      },
      { property: "og:title", content: "Registros DNS — Nimbus DNS Console" },
      {
        property: "og:description",
        content: "Administre los registros DNS y el estado de salud de cada IP.",
      },
    ],
  }),
  component: RecordsPage,
});

const TYPE_STYLES: Record<RecordType, string> = {
  multi: "bg-cyan/12 text-cyan ring-cyan/25",
  "round-trip": "bg-cyan/12 text-cyan ring-cyan/25",
  weight: "bg-amber/12 text-amber ring-amber/25",
  single: "bg-surface text-ink ring-edge",
  geo: "bg-surface text-ink ring-edge",
};

function RecordsPage() {
  const [search, setSearch] = useState("");
  const qc = useQueryClient();
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["records"],
    queryFn: listRecords,
  });

  const remove = useMutation({
    mutationFn: deleteRecord,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["records"] }),
  });

  const filtered = (data ?? []).filter((r) =>
    r.hostname.toLowerCase().includes(search.trim().toLowerCase()),
  );

  return (
    <AppShell
      title="Registros DNS"
      badge={data ? `${data.length} en total` : undefined}
      actions={
        <div className="relative">
          <span className="absolute top-1/2 left-3 -translate-y-1/2 text-sm text-muted">⌕</span>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por dominio…"
            aria-label="Buscar por nombre de dominio"
            className="field w-[240px] pl-9"
          />
        </div>
      }
    >
      {isLoading ? <LoadingState label="Cargando registros DNS…" /> : null}
      {isError ? <ErrorState error={error} onRetry={() => refetch()} /> : null}

      {data ? (
        <div className="panel overflow-hidden">
          <div className="flex h-12 items-center justify-between border-b border-edge/60 px-5">
            <p className="text-sm font-medium">Listado de registros</p>
            <Link to="/registros/nuevo" className="btn-primary">
              <span className="text-lg leading-none">+</span>Crear nuevo registro
            </Link>
          </div>

          {remove.isError ? (
            <p className="border-b border-edge/60 px-5 py-3 text-sm text-red">
              No se pudo eliminar el registro. Intente de nuevo.
            </p>
          ) : null}

          {filtered.length === 0 ? (
            <EmptyState label="No hay registros que coincidan con la búsqueda." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-edge/60 text-left text-[11px] tracking-[0.12em] text-muted uppercase">
                    <th className="px-5 py-3 font-medium">Dominio</th>
                    <th className="px-5 py-3 font-medium">Tipo</th>
                    <th className="px-5 py-3 font-medium">Estado por IP</th>
                    <th className="px-5 py-3 text-right font-medium">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-edge/50">
                  {filtered.map((record) => {
                    const ok = record.ips.filter((i) => i.healthy).length;
                    const failing = record.ips.length - ok;
                    return (
                      <tr key={record.id} className="transition-colors hover:bg-surface/60">
                        <td className="px-5 py-3.5 font-mono text-ink">{record.hostname}</td>
                        <td className="px-5 py-3.5">
                          <span
                            className={`inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-medium ring-1 ${TYPE_STYLES[record.type]}`}
                          >
                            {record.type}
                          </span>
                        </td>
                        <td className="px-5 py-3.5">
                          <div className="flex items-center gap-1.5">
                            {record.ips.map((ip) => (
                              <span
                                key={ip.id}
                                title={`${ip.ip} · ${ip.healthy ? "healthy" : "unhealthy"}`}
                                className={`size-2 rounded-full ${ip.healthy ? "bg-green" : "bg-red"}`}
                              />
                            ))}
                            <span
                              className={`ml-1 font-mono text-[11px] ${failing ? "text-red" : "text-muted"}`}
                            >
                              {failing ? `fallo en ${failing}` : `${ok}/${record.ips.length}`}
                            </span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5">
                          <div className="flex items-center justify-end gap-2">
                            <Link
                              to="/registros/$id"
                              params={{ id: record.id }}
                              className="text-xs font-medium text-muted transition-colors hover:text-ink"
                            >
                              Editar
                            </Link>
                            <span className="text-edge">/</span>
                            <button
                              onClick={() => {
                                if (confirm(`¿Eliminar ${record.hostname}?`)) {
                                  remove.mutate(record.id);
                                }
                              }}
                              disabled={remove.isPending}
                              className="text-xs font-medium text-red/80 transition-colors hover:text-red disabled:opacity-50"
                            >
                              Eliminar
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : null}
    </AppShell>
  );
}
