import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { ErrorState, LoadingState } from "@/components/States";
import { listHealthChecks, listRecords } from "@/lib/dns-api";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Resumen — Nimbus DNS Console" },
      {
        name: "description",
        content:
          "Panel de administración del sistema DNS: registros, estado de IPs y health checks en un solo lugar.",
      },
      { property: "og:title", content: "Resumen — Nimbus DNS Console" },
      {
        property: "og:description",
        content: "Estado general de los registros DNS y sus health checks.",
      },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const records = useQuery({ queryKey: ["records"], queryFn: listRecords });
  const checks = useQuery({ queryKey: ["health-checks"], queryFn: listHealthChecks });

  const ips = (records.data ?? []).flatMap((r) => r.ips);
  const healthy = ips.filter((i) => i.healthy).length;
  const unhealthy = ips.length - healthy;
  const total = records.data?.length ?? 0;

  return (
    <AppShell
      title="Resumen"
      badge={records.data ? `${total} registros` : undefined}
      actions={
        <Link to="/registros/nuevo" className="btn-primary">
          <span className="text-lg leading-none">+</span>Crear nuevo registro
        </Link>
      }
    >
      {records.isLoading ? <LoadingState /> : null}
      {records.isError ? (
        <ErrorState error={records.error} onRetry={() => records.refetch()} />
      ) : null}

      {records.data ? (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            <div className="diag panel p-5">
              <p className="text-[11px] tracking-[0.14em] text-muted uppercase">
                Total registros
              </p>
              <p className="mt-2 font-display text-4xl font-semibold tracking-tight">
                {total}
              </p>
              <p className="mt-1 text-xs text-muted">Dominios administrados</p>
            </div>
            <div className="rounded-xl bg-surface/40 p-5 backdrop-blur-md ring-1 ring-green/25">
              <div className="flex items-center gap-2">
                <span className="size-2 rounded-full bg-green" />
                <p className="text-[11px] tracking-[0.14em] text-muted uppercase">
                  IPs saludables
                </p>
              </div>
              <p className="mt-2 font-display text-4xl font-semibold tracking-tight text-green">
                {healthy}
              </p>
              <p className="mt-1 text-xs text-muted">
                {ips.length ? Math.round((healthy / ips.length) * 100) : 0}% del total
              </p>
            </div>
            <div className="rounded-xl bg-surface/40 p-5 backdrop-blur-md ring-1 ring-red/25">
              <div className="flex items-center gap-2">
                <span className="size-2 rounded-full bg-red" />
                <p className="text-[11px] tracking-[0.14em] text-muted uppercase">
                  IPs no saludables
                </p>
              </div>
              <p className="mt-2 font-display text-4xl font-semibold tracking-tight text-red">
                {unhealthy}
              </p>
              <p className="mt-1 text-xs text-muted">Requieren revisión</p>
            </div>
          </div>

          <div className="panel overflow-hidden">
            <div className="flex h-12 items-center justify-between border-b border-edge/60 px-5">
              <p className="text-sm font-medium">Registros por tipo</p>
              <Link to="/registros" className="text-xs text-cyan hover:underline">
                Ver todos
              </Link>
            </div>
            <div className="grid gap-px bg-edge/40 sm:grid-cols-5">
              {(["single", "multi", "round-trip", "weight", "geo"] as const).map((t) => (
                <div key={t} className="bg-surface/40 p-5">
                  <p className="font-mono text-[11px] text-muted">{t}</p>
                  <p className="mt-1 font-display text-2xl font-semibold">
                    {records.data!.filter((r) => r.type === t).length}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="panel overflow-hidden">
            <div className="flex h-12 items-center justify-between border-b border-edge/60 px-5">
              <p className="text-sm font-medium">Health checks configurados</p>
              <Link to="/health-checks" className="text-xs text-cyan hover:underline">
                Administrar
              </Link>
            </div>
            <div className="p-5 text-sm text-muted">
              {checks.isLoading
                ? "Cargando…"
                : `${checks.data?.length ?? 0} configuraciones reutilizables disponibles.`}
            </div>
          </div>
        </>
      ) : null}
    </AppShell>
  );
}
