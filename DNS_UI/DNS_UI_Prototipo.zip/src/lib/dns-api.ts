/**
 * Capa de acceso a la "DNS API".
 *
 * Hoy devuelve datos mock en memoria. Para conectar la API real solo hay que
 * reemplazar el cuerpo de cada función por un fetch a `apiUrl("/api/...")`,
 * manteniendo la misma firma. Ejemplo:
 *
 *   export async function listRecords(): Promise<DnsRecord[]> {
 *     const res = await fetch(apiUrl("/api/records"));
 *     if (!res.ok) throw new Error("No se pudieron cargar los registros");
 *     return res.json();
 *   }
 */
import type {
  DnsRecord,
  HealthCheck,
  IpCountryEntry,
} from "./dns-types";

const LATENCY = 350;

function delay<T>(value: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), LATENCY));
}

function uid(): string {
  return Math.random().toString(36).slice(2, 10);
}

let healthChecks: HealthCheck[] = [
  {
    id: "hc-tcp-443",
    name: "api-tcp-443",
    type: "TCP",
    timeout: 5,
    retries: 3,
    interval: 30,
    basicAuthEnabled: false,
  },
  {
    id: "hc-http-health",
    name: "web-http-health",
    type: "HTTP",
    timeout: 3,
    retries: 2,
    interval: 15,
    path: "/health",
    expectedCodes: [200, 204],
    basicAuthEnabled: false,
  },
  {
    id: "hc-http-auth",
    name: "portal-http-auth",
    type: "HTTP",
    timeout: 4,
    retries: 3,
    interval: 60,
    path: "/status",
    expectedCodes: [200],
    basicAuthEnabled: true,
    username: "monitor",
    password: "secreto",
  },
];

let records: DnsRecord[] = [
  {
    id: "rec-1",
    hostname: "api.nimbus-uni.edu",
    type: "multi",
    ips: [
      { id: uid(), ip: "10.0.1.14", healthy: true, healthCheckId: "hc-tcp-443" },
      { id: uid(), ip: "10.0.1.15", healthy: true, healthCheckId: "hc-tcp-443" },
      { id: uid(), ip: "10.0.1.16", healthy: true, healthCheckId: null },
    ],
  },
  {
    id: "rec-2",
    hostname: "cdn.nimbus-uni.edu",
    type: "single",
    ips: [
      { id: uid(), ip: "172.16.4.8", healthy: true, healthCheckId: "hc-http-health" },
    ],
  },
  {
    id: "rec-3",
    hostname: "portal.nimbus-uni.edu",
    type: "weight",
    ips: [
      { id: uid(), ip: "10.4.2.10", weight: 70, healthy: true, healthCheckId: "hc-http-auth" },
      { id: uid(), ip: "10.4.2.11", weight: 30, healthy: false, healthCheckId: "hc-http-auth" },
    ],
  },
  {
    id: "rec-4",
    hostname: "mail.nimbus-uni.edu",
    type: "geo",
    ips: [
      { id: uid(), ip: "10.7.1.2", country: "Costa Rica", healthy: true, healthCheckId: "hc-tcp-443" },
      { id: uid(), ip: "10.7.1.3", country: "Chile", healthy: false, healthCheckId: null },
    ],
  },
  {
    id: "rec-5",
    hostname: "edge.nimbus-uni.edu",
    type: "round-trip",
    ips: [
      { id: uid(), ip: "10.9.0.2", healthy: true, healthCheckId: "hc-http-health" },
      { id: uid(), ip: "10.9.0.3", healthy: true, healthCheckId: "hc-http-health" },
      { id: uid(), ip: "10.9.0.4", healthy: true, healthCheckId: null },
    ],
  },
];

let ipCountries: IpCountryEntry[] = Array.from({ length: 34 }, (_, i) => {
  const countries = [
    "Costa Rica",
    "México",
    "Chile",
    "Argentina",
    "Colombia",
    "España",
    "Estados Unidos",
  ];
  const cities = ["San José", "CDMX", "Santiago", "Buenos Aires", "Bogotá", "Madrid", "Austin"];
  const idx = i % countries.length;
  return {
    id: `ipc-${i + 1}`,
    startIp: `10.${i}.0.0`,
    endIp: `10.${i}.255.255`,
    country: countries[idx]!,
    city: cities[idx]!,
  };
});

/* ---------------- Registros DNS ---------------- */

export async function listRecords(): Promise<DnsRecord[]> {
  return delay(records.map((r) => ({ ...r, ips: r.ips.map((ip) => ({ ...ip })) })));
}

export async function getRecord(id: string): Promise<DnsRecord> {
  const found = records.find((r) => r.id === id);
  if (!found) throw new Error("El registro solicitado no existe");
  return delay({ ...found, ips: found.ips.map((ip) => ({ ...ip })) });
}

export async function createRecord(data: Omit<DnsRecord, "id">): Promise<DnsRecord> {
  const created: DnsRecord = { ...data, id: `rec-${uid()}` };
  records = [...records, created];
  return delay(created);
}

export async function updateRecord(id: string, data: Omit<DnsRecord, "id">): Promise<DnsRecord> {
  const updated: DnsRecord = { ...data, id };
  records = records.map((r) => (r.id === id ? updated : r));
  return delay(updated);
}

export async function deleteRecord(id: string): Promise<void> {
  records = records.filter((r) => r.id !== id);
  return delay(undefined);
}

/* ---------------- Health checks ---------------- */

export async function listHealthChecks(): Promise<HealthCheck[]> {
  return delay(healthChecks.map((h) => ({ ...h })));
}

export async function createHealthCheck(data: Omit<HealthCheck, "id">): Promise<HealthCheck> {
  const created: HealthCheck = { ...data, id: `hc-${uid()}` };
  healthChecks = [...healthChecks, created];
  return delay(created);
}

export async function updateHealthCheck(id: string, data: Omit<HealthCheck, "id">): Promise<HealthCheck> {
  const updated: HealthCheck = { ...data, id };
  healthChecks = healthChecks.map((h) => (h.id === id ? updated : h));
  return delay(updated);
}

export async function deleteHealthCheck(id: string): Promise<void> {
  healthChecks = healthChecks.filter((h) => h.id !== id);
  return delay(undefined);
}

/* ---------------- IP to Country ---------------- */

export async function listIpCountries(): Promise<IpCountryEntry[]> {
  return delay(ipCountries.map((e) => ({ ...e })));
}

export async function createIpCountry(data: Omit<IpCountryEntry, "id">): Promise<IpCountryEntry> {
  const created: IpCountryEntry = { ...data, id: `ipc-${uid()}` };
  ipCountries = [created, ...ipCountries];
  return delay(created);
}

export async function updateIpCountry(id: string, data: Omit<IpCountryEntry, "id">): Promise<IpCountryEntry> {
  const updated: IpCountryEntry = { ...data, id };
  ipCountries = ipCountries.map((e) => (e.id === id ? updated : e));
  return delay(updated);
}

export async function deleteIpCountry(id: string): Promise<void> {
  ipCountries = ipCountries.filter((e) => e.id !== id);
  return delay(undefined);
}
