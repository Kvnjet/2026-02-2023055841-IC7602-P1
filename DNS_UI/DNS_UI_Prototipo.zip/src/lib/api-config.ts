/**
 * Configuración de la DNS API.
 * Nunca se quema la URL en el código: viene de la variable de entorno
 * VITE_API_URL (inyectada por Docker / Kubernetes en tiempo de build).
 */
export const API_BASE_URL: string = import.meta.env["VITE_API_URL"] ?? "";

/** Simula la latencia de red mientras se usan datos mock. */
export const USE_MOCK_DATA: boolean =
  (import.meta.env["VITE_USE_MOCK"] ?? "true") !== "false";

export function apiUrl(path: string): string {
  return `${API_BASE_URL.replace(/\/$/, "")}${path}`;
}
