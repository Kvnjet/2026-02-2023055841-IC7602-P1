export type RecordType = "single" | "multi" | "round-trip" | "weight" | "geo";

export const RECORD_TYPES: RecordType[] = [
  "single",
  "multi",
  "round-trip",
  "weight",
  "geo",
];

export type IpEntry = {
  id: string;
  ip: string;
  /** Solo para type = "weight" (0-100) */
  weight?: number | undefined;
  /** Solo para type = "geo" */
  country?: string | undefined;
  /** Id del health check asociado */
  healthCheckId?: string | null | undefined;
  healthy: boolean;
};

export type DnsRecord = {
  id: string;
  hostname: string;
  type: RecordType;
  ips: IpEntry[];
};

export type HealthCheckType = "TCP" | "HTTP";

export type HealthCheck = {
  id: string;
  name: string;
  type: HealthCheckType;
  timeout: number;
  retries: number;
  interval: number;
  path?: string | undefined;
  expectedCodes?: number[] | undefined;
  basicAuthEnabled: boolean;
  username?: string | undefined;
  password?: string | undefined;
};

export type IpCountryEntry = {
  id: string;
  startIp: string;
  endIp: string;
  country: string;
  city?: string | undefined;
};

export const HTTP_CODES = [200, 201, 202, 204, 301, 302, 304, 401, 403];

export const COUNTRIES = [
  "Costa Rica",
  "México",
  "Guatemala",
  "Panamá",
  "Colombia",
  "Chile",
  "Argentina",
  "Brasil",
  "España",
  "Estados Unidos",
  "Canadá",
  "Alemania",
  "Francia",
  "Japón",
];

const IPV4 =
  /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;

export function isValidIpv4(value: string): boolean {
  return IPV4.test(value.trim());
}
