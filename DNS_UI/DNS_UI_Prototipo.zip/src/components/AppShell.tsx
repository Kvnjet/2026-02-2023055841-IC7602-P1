import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

const NAV = [
  { to: "/", label: "Resumen" },
  { to: "/registros", label: "Registros DNS" },
  { to: "/health-checks", label: "Health Checks" },
  { to: "/ip-country", label: "IP a País" },
] as const;

export function AppShell({
  title,
  badge,
  actions,
  children,
}: {
  title: string;
  badge?: string | undefined;
  actions?: ReactNode | undefined;
  children: ReactNode;
}) {
  return (
    <div className="min-h-screen text-ink">
      <div className="flex flex-col md:flex-row">
        <aside className="shrink-0 border-b border-edge/60 bg-surface/40 backdrop-blur-md md:min-h-screen md:w-[248px] md:border-r md:border-b-0">
          <div className="flex h-16 items-center gap-2.5 border-b border-edge/60 px-5">
            <div className="grid size-8 place-items-center rounded-lg bg-cyan/15 font-display text-sm font-semibold text-cyan ring-1 ring-cyan/30">
              N
            </div>
            <div>
              <p className="font-display text-[15px] leading-none font-semibold tracking-tight">
                NIMBUS
              </p>
              <p className="mt-1 text-[10px] tracking-[0.18em] text-muted uppercase">
                DNS Console
              </p>
            </div>
          </div>
          <nav className="space-y-1 px-3 py-4">
            <p className="px-3 pb-1.5 text-[10px] tracking-[0.16em] text-muted uppercase">
              Navegación
            </p>
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.to === "/" }}
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted transition-colors hover:text-ink"
                activeProps={{
                  className:
                    "flex items-center gap-3 rounded-lg bg-cyan/10 px-3 py-2 text-sm font-medium text-cyan ring-1 ring-cyan/25",
                }}
              >
                <span className="grid size-4 shrink-0 place-items-center">
                  <span className="size-2 rounded-full bg-current opacity-70" />
                </span>
                {item.label}
              </Link>
            ))}
          </nav>
        </aside>

        <main className="min-w-0 flex-1">
          <div className="flex h-16 flex-wrap items-center justify-between gap-3 border-b border-edge/60 px-5 md:px-7">
            <div className="flex items-center gap-3">
              <h1 className="font-display text-xl font-semibold tracking-tight">{title}</h1>
              {badge ? (
                <span className="rounded-md bg-surface px-2 py-0.5 font-mono text-[11px] text-muted ring-1 ring-edge">
                  {badge}
                </span>
              ) : null}
            </div>
            {actions}
          </div>
          <div className="space-y-6 p-5 md:p-7">{children}</div>
        </main>
      </div>
    </div>
  );
}
