import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { listHealthChecks } from "@/lib/dns-api";
import {
  COUNTRIES,
  RECORD_TYPES,
  isValidIpv4,
  type DnsRecord,
  type IpEntry,
  type RecordType,
} from "@/lib/dns-types";

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function emptyIp(type: RecordType): IpEntry {
  return {
    id: uid(),
    ip: "",
    healthy: true,
    healthCheckId: null,
    ...(type === "weight" ? { weight: 50 } : {}),
    ...(type === "geo" ? { country: COUNTRIES[0] } : {}),
  };
}

export function RecordForm({
  initial,
  submitting,
  submitError,
  onSubmit,
  onCancel,
}: {
  initial?: DnsRecord;
  submitting: boolean;
  submitError?: unknown;
  onSubmit: (data: Omit<DnsRecord, "id">) => void;
  onCancel: () => void;
}) {
  const [hostname, setHostname] = useState(initial?.hostname ?? "");
  const [type, setType] = useState<RecordType>(initial?.type ?? "single");
  const [ips, setIps] = useState<IpEntry[]>(
    initial?.ips.length ? initial.ips : [emptyIp(initial?.type ?? "single")],
  );
  const [touched, setTouched] = useState(false);

  const checks = useQuery({ queryKey: ["health-checks"], queryFn: listHealthChecks });

  const isSingle = type === "single";
  const errors: string[] = [];
  if (!hostname.trim()) errors.push("Escriba el nombre de dominio.");
  if (ips.some((i) => !isValidIpv4(i.ip)))
    errors.push("Todas las direcciones IP deben tener formato IPv4 válido (ej. 10.0.0.1).");
  if (type === "weight" && ips.some((i) => (i.weight ?? -1) < 0 || (i.weight ?? 101) > 100))
    errors.push("Los pesos deben estar entre 0 y 100.");
  if (type === "geo" && ips.some((i) => !i.country)) errors.push("Seleccione un país por cada IP.");

  function changeType(next: RecordType) {
    setType(next);
    setIps((prev) => {
      const base = next === "single" ? prev.slice(0, 1) : prev;
      return (base.length ? base : [emptyIp(next)]).map((i) => ({
        ...i,
        weight: next === "weight" ? (i.weight ?? 50) : undefined,
        country: next === "geo" ? (i.country ?? COUNTRIES[0]) : undefined,
      }));
    });
  }

  function patchIp(id: string, patch: Partial<IpEntry>) {
    setIps((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        setTouched(true);
        if (errors.length) return;
        onSubmit({ hostname: hostname.trim(), type, ips });
      }}
      className="space-y-6"
    >
      <div className="panel p-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="mb-1.5 block text-[11px] tracking-[0.14em] text-muted uppercase">
              Nombre de dominio
            </span>
            <input
              value={hostname}
              onChange={(e) => setHostname(e.target.value)}
              placeholder="api.nimbus-uni.edu"
              className="field font-mono"
            />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-[11px] tracking-[0.14em] text-muted uppercase">
              Tipo de registro
            </span>
            <select
              value={type}
              onChange={(e) => changeType(e.target.value as RecordType)}
              className="field"
            >
              {RECORD_TYPES.map((t) => (
                <option key={t} value={t} className="bg-surface">
                  {t}
                </option>
              ))}
            </select>
          </label>
        </div>
        <p className="mt-3 text-xs text-muted">
          {type === "single" && "Una sola IP responde a todas las consultas."}
          {type === "multi" && "Las consultas se reparten entre las IPs (round-robin)."}
          {type === "round-trip" &&
            "Se listan las IPs candidatas; el backend elige la más cercana al cliente."}
          {type === "weight" && "La IP con mayor peso atiende más consultas."}
          {type === "geo" && "Cada país recibe la IP que se le asigne."}
        </p>
      </div>

      <div className="panel overflow-hidden">
        <div className="flex h-12 items-center justify-between border-b border-edge/60 px-5">
          <p className="text-sm font-medium">
            {isSingle ? "Dirección IP" : "Direcciones IP asociadas"}
          </p>
          {!isSingle ? (
            <button
              type="button"
              onClick={() => setIps((prev) => [...prev, emptyIp(type)])}
              className="btn-ghost"
            >
              + Agregar IP
            </button>
          ) : null}
        </div>

        <div className="divide-y divide-edge/50">
          {ips.map((entry) => {
            const invalid = touched && !isValidIpv4(entry.ip);
            return (
              <div key={entry.id} className="grid gap-3 p-5 md:grid-cols-12">
                {type === "geo" ? (
                  <label className="md:col-span-3">
                    <span className="mb-1.5 block text-[11px] text-muted">País</span>
                    <select
                      value={entry.country ?? ""}
                      onChange={(e) => patchIp(entry.id, { country: e.target.value })}
                      className="field"
                    >
                      {COUNTRIES.map((c) => (
                        <option key={c} value={c} className="bg-surface">
                          {c}
                        </option>
                      ))}
                    </select>
                  </label>
                ) : null}

                <label className={type === "geo" ? "md:col-span-4" : "md:col-span-5"}>
                  <span className="mb-1.5 block text-[11px] text-muted">Dirección IPv4</span>
                  <input
                    value={entry.ip}
                    onChange={(e) => patchIp(entry.id, { ip: e.target.value })}
                    placeholder="10.0.0.1"
                    className="field font-mono"
                  />
                  {invalid ? (
                    <span className="mt-1 block text-[11px] text-red">Formato IPv4 inválido</span>
                  ) : null}
                </label>

                {type === "weight" ? (
                  <label className="md:col-span-2">
                    <span className="mb-1.5 block text-[11px] text-muted">Peso (0-100)</span>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={entry.weight ?? 0}
                      onChange={(e) => patchIp(entry.id, { weight: Number(e.target.value) })}
                      className="field font-mono"
                    />
                  </label>
                ) : null}

                <label className={type === "weight" || type === "geo" ? "md:col-span-4" : "md:col-span-5"}>
                  <span className="mb-1.5 block text-[11px] text-muted">Health check</span>
                  <select
                    value={entry.healthCheckId ?? ""}
                    onChange={(e) =>
                      patchIp(entry.id, { healthCheckId: e.target.value || null })
                    }
                    className="field"
                  >
                    <option value="" className="bg-surface">
                      Sin health check
                    </option>
                    {(checks.data ?? []).map((hc) => (
                      <option key={hc.id} value={hc.id} className="bg-surface">
                        {hc.name} ({hc.type})
                      </option>
                    ))}
                  </select>
                </label>

                {!isSingle ? (
                  <div className="flex items-end md:col-span-1">
                    <button
                      type="button"
                      onClick={() => setIps((prev) => prev.filter((i) => i.id !== entry.id))}
                      disabled={ips.length === 1}
                      className="text-xs font-medium text-red/80 hover:text-red disabled:opacity-40"
                    >
                      Quitar
                    </button>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      </div>

      {touched && errors.length ? (
        <ul className="space-y-1 rounded-xl bg-red/8 p-4 text-sm text-red ring-1 ring-red/30">
          {errors.map((e) => (
            <li key={e}>• {e}</li>
          ))}
        </ul>
      ) : null}

      {submitError ? (
        <p className="rounded-xl bg-red/8 p-4 text-sm text-red ring-1 ring-red/30">
          No se pudo guardar el registro. Revise la conexión con la DNS API.
        </p>
      ) : null}

      <div className="flex items-center gap-3">
        <button type="submit" disabled={submitting} className="btn-primary disabled:opacity-60">
          {submitting ? "Guardando…" : "Guardar"}
        </button>
        <button type="button" onClick={onCancel} className="btn-ghost">
          Cancelar
        </button>
      </div>
    </form>
  );
}
