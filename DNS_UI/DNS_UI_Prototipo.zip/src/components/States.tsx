export function LoadingState({ label = "Cargando información…" }: { label?: string }) {
  return (
    <div className="panel flex items-center gap-3 p-6 text-sm text-muted">
      <span className="size-4 animate-spin rounded-full border-2 border-edge border-t-cyan" />
      {label}
    </div>
  );
}

export function ErrorState({
  error,
  onRetry,
}: {
  error: unknown;
  onRetry?: () => void;
}) {
  const message =
    error instanceof Error ? error.message : "Ocurrió un problema al contactar la DNS API.";
  return (
    <div className="rounded-xl bg-red/8 p-6 ring-1 ring-red/30">
      <p className="text-sm font-medium text-red">No se pudo cargar la información</p>
      <p className="mt-1 text-sm text-muted">{message}</p>
      {onRetry ? (
        <button onClick={onRetry} className="btn-ghost mt-4">
          Reintentar
        </button>
      ) : null}
    </div>
  );
}

export function EmptyState({ label }: { label: string }) {
  return <div className="p-8 text-center text-sm text-muted">{label}</div>;
}
